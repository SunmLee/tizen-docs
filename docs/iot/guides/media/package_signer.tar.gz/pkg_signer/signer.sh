#!/bin/bash
#---------------------------------------------------------#
#                Update Package Signer
#
#  Make signature of given file and packaging it
#---------------------------------------------------------#

print_usage() {
	echo "Usage: signer.sh PRIVATE_KEY UPDATE_PACKAGE"
	echo "Generate signature appended package of UPDATE_PACKAGE"
}

if [ $# -ne 2 ]; then
	print_usage
	exit
fi

prkey=$1
upkg=$2

if [ ! -e $prkey ]; then
	echo "Error: $prkey does not exist"
	exit
fi

if [ ! -e $upkg ]; then
	echo "Error: $upkg does not exist"
	exit
fi

gzip -d $upkg
upkg=${upkg%.*}

command -v "openssl" >/dev/null
if [ $? -ne 0 ]; then
	echo "Error: openssl is mandatory. Please install it first"
	exit
fi

temp=$(mktemp sign.XXXXXX)
openssl dgst -sha256 -sign $prkey -keyform DER -out $temp $upkg
openssl base64 -in $temp -out signature
rm $temp

tar rvf $upkg signature
rm signature
gzip $upkg
