#!/bin/bash
#---------------------------------------------------------#
#                Update Package Verifier
#
#  Verify update package signed by signer.sh
#  exit value
#   0: verify passed
#   1: verify failed
#   2: incorrect usage or other errors
#---------------------------------------------------------#

print_usage() {
	echo "Usage: verifier.sh CERTIFICATE UPDATE_PACKAGE SIGNATURE"
	echo "Verify signature of SIGNED_UPDATE_PACKAGE"
}

if [ $# -ne 3 ]; then
	print_usage
	exit 2
fi

cert=$1
upkg=$2
signature=$3

if [ ! -e $cert ]; then
	echo "Error: $cert does not exist"
	exit 2
fi

if [ ! -e $upkg ]; then
	echo "Error: $upkg does not exist"
	exit 2
fi

if [ ! -e $signature ]; then
	echo "Error: $signature does not exist"
	exit 2
fi

command -v "openssl" >/dev/null
if [ $? -ne 0 ]; then
	echo "Error: openssl is mandatory. Please install it first"
	exit 2
fi

pukey=publickey.pem
temp=$(mktemp sign.XXXXXX)
openssl x509 -pubkey -noout -in $cert > $pukey
openssl base64 -d -in $signature -out $temp
openssl dgst -sha256 -verify $pukey -signature $temp $upkg >/dev/null
ret=$?
rm $pukey $temp

if [ $ret -ne 0 ]; then
	echo "Verify failed"
	exit 1
else
	echo "Verify passed"
	exit 0
fi
