#/bin/sh

capability() {
	# -n name
	# -m - -d can dump all extended attributes
	# -e hex encoding
	TARGET="$1"
	CAP_ATTR_STR=`getfattr -hP -n security.capability -e hex "${TARGET}" 2>/dev/null | grep security.capability`
	ACL_ATTR_STR=`getfattr -hP -n system.posix_acl_access -e hex "${TARGET}" 2>/dev/null | grep system.posix_acl_access`
}

chsmack_attr() {
	TARGET="$1"
	ATTRS=`attr -Slq "${TARGET}"`
	CHSMACK_STR="${TARGET}"
	for attrname in ${ATTRS}
	do
		value=`attr -Sq -g ${attrname} "${TARGET}"`

		case "${attrname}" in
		SMACK64)
			chsmack_attrname="access"
			;;
		SMACK64EXEC)
			chsmack_attrname="execute"
			;;
		SMACK64TRANSMUTE)
			chsmack_attrname="transmute"
			;;
		SMACK64MMAP)
			chsmack_attrname="mmap"
			;;
		*)
			continue
		;;
		esac

		CHSMACK_STR="${CHSMACK_STR} ${chsmack_attrname}=\"${value}\""

	done
}

capability "$1"
chsmack_attr "$1"

echo "${CAP_ATTR_STR}:${ACL_ATTR_STR}:${CHSMACK_STR}"


