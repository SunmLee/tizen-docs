#!/bin/bash


#==================
# funtions
#==================

#------------------------------------------------------------------------------
# Function :
#	fn_gen_update_cfg
#
# Description :
#	read delta configuration file for generating update configuration file to be used during update.
#	delta config file format : PART_NAME PART_BIN DELTA_BIN UPDATE_TYPE BLK_DEV BLK_OFFSET (deliminator : TAB)

fn_gen_update_cfg()
{
	in_file=$1
	out_file=$2

	if [ ! -r ${in_file} ]; then
		echo "file ${in_file} cannot be read"
		return 1
	fi

	line_num=0
	while read line
	do
		# skip comment line
		if [ "${line:0:1}" = "#" ]; then
			continue
		fi

		# skip empty line
		line_len=${#line}
		if [ "${line_len}" = "0" ]; then
			continue
		fi


		fields=(${line})
		PART_NAME[${line_num}]=${fields[0]}
		PART_BIN[${line_num}]=${fields[1]}
		DELTA_BIN[${line_num}]=${fields[2]}
		UPDATE_TYPE[${line_num}]=${fields[3]}
		BLK_DEV[${line_num}]=${fields[4]}
		BLK_OFFSET[${line_num}]=${fields[5]}

		line_num=$(($line_num + 1))

	done < ${in_file}

	PART_NUM=${line_num}

	if [ -f ${out_file} ]; then
		sudo rm -fr ${out_file}
	fi

	for ((update_idx=0;update_idx<PART_NUM;update_idx++))
	do
		f1=${PART_NAME[${update_idx}]}
		f2=${DELTA_BIN[${update_idx}]}
		f3=${UPDATE_TYPE[${update_idx}]}
		f4=${BLK_DEV[${update_idx}]}
		f5=${BLK_OFFSET[${update_idx}]}

		echo -e "$f1\t\t$f2\t\t$f3\t\t$f4\t\t$f5" >> ${out_file}
	done

	return 0
}

#------------------------------------------------------------------------------
# Function :
#	fn_set_default_params
#
# Description :
#	set default params used globally in this script
#

fn_set_default_params()
{
	MY_ID=`whoami`
	MK_PART_DELTA=${COMMON_BINDIR}/mk_part_delta.sh
	UPDATE_CFG_PATH=./update.cfg
	DELTA_UA=./data/delta.ua
	UPDATE_MANAGER=./data/upgrade-trigger.sh

	LOG_PATH=./data/Delta.log

	# Clean previous data
	rm -rf data result
	mkdir data	
}

#------------------------------------------------------------------------------
# Function :
#	fn_print_update_cfg

fn_print_update_cfg()
{
	for ((update_idx=0;update_idx<PART_NUM;update_idx++))
	do
			echo "------------------------------"
			echo "[PART_NAME]    ${PART_NAME[${update_idx}]}"
			echo "[DELTA_BIN]    ${DELTA_BIN[${update_idx}]}"
			echo "[UPDATE_TYPE]  ${UPDATE_TYPE[${update_idx}]}"
			echo "[BLK_DEV]      ${BLK_DEV[${update_idx}]}"
			echo "[BLK_OFFSET]   ${BLK_OFFSET[${update_idx}]}"

	done
	echo "------------------------------"
}

#------------------------------------------------------------------------------
# Function :
#	fn_get_tar_file_names
#
# Description :
#	find tar file name (without path) that contains given partition binary
#

fn_get_tar_file_names()
{
	BIN_TO_FIND=$1

	#--- find which tar contains the binary ---
	for tar_file in ${OLD_TAR_LIST}
	do
		result=`tar -tvf ${DATA_DIR}/${OLD_TAR_DIR}/${tar_file} | grep " ${BIN_TO_FIND}$"`
		if [ "$?" = "0" ]; then
			OLD_TAR_FILE=${tar_file}
			break
		fi
	done

	for tar_file in ${NEW_TAR_LIST}
	do
		result=`tar -tvf ${DATA_DIR}/${NEW_TAR_DIR}/${tar_file} | grep " ${BIN_TO_FIND}$"`
		if [ "$?" = "0" ]; then
			NEW_TAR_FILE=${tar_file}
			break
		fi
	done

}

#------------------------------------------------------------------------------
# Function :
#	fn_extract_from_image
#
# Description :
#	extract some files from given image
#

fn_extract_from_image()
{
	CUR_DIR=`pwd`
	DATA_DIR=./data
	IMAGE=$1
	TARGET_FILE=$2
	MNT_PNT=TMP_MNT

	cd ${DATA_DIR}
	mkdir -p ${MNT_PNT}

	result=`tar -tvf ${NEW_TAR_FILE} | grep " ${IMAGE}$"`
	if [ "$?" != "0" ]; then
		echo "Error: New binary ${NEW_TAR_FILE} does not contain $1"
		return;
	fi

	tar xvf ${NEW_TAR_FILE} ${IMAGE}
	if [ "$?" != "0" ]; then
		echo "Error: Extract ${IMAGE} was failed"
		return;
	fi

	sudo mount -t ext4 -o loop ${IMAGE} ${MNT_PNT}
	if [ "$?" != "0" ]; then
		echo "Error: Mount ${IMAGE} was failed"
		return;
	fi

	EXTRACT_FILE="${MNT_PNT}${TARGET_FILE}"
	if [ -e ${EXTRACT_FILE} ]; then
		sudo cp ${EXTRACT_FILE} ../${DELTA_DIR}
	else
		echo "There is no ${TARGET_FILE} in ${IMAGE}"
	fi

	sudo umount ${MNT_PNT}
	sudo rm -rf ${MNT_PNT}
	sudo rm -f ${IMAGE}

	cd ${CUR_DIR}
}

###############################################################################
#==================
# Main Start
#==================

COMMON_BINDIR=${PWD}

fn_set_default_params

fn_gen_update_cfg ${DELTA_CFG_PATH} ${UPDATE_CFG_PATH}

START_TIMESTAMP="$(date +%T)"

#--- archive result directory ---
echo "Make Delta file"
RESULT_DIR=result
DELTA_DIR=${RESULT_DIR}/DELTA
mkdir -p ${DELTA_DIR}

#--- make delta for each partition ---
for ((part_num=0;part_num<PART_NUM;part_num++))
do
	part_name=${PART_NAME[${part_num}]}
	update_type=${UPDATE_TYPE[${part_num}]}
	part_bin=${PART_BIN[${part_num}]}
	delta_bin=${DELTA_BIN[${part_num}]}

	PART_OUT=${part_name}_OUT

	${MK_PART_DELTA} ${part_name} ${update_type} ${part_bin} ${delta_bin}
	if [ "$?" = "0" ]; then
		if [ "${update_type}" = "DELTA_FS" ]; then
			sudo mv data/${PART_OUT} ${RESULT_DIR}/${part_bin}
			sudo mv ${RESULT_DIR}/${part_bin} ${DELTA_DIR}
		else
			sudo mv data/${PART_OUT} ${RESULT_DIR}/${part_bin}
			sudo mv ${RESULT_DIR}/${part_bin}/${delta_bin} ${DELTA_DIR}
		fi
	else
		sudo rm -rf ${RESULT_DIR}/${part_bin}
		echo "Error: Abort Delta Generation"
		exit 1
	fi

	sudo rm -rf ${RESULT_DIR}/${part_bin}
done

#move update.cfg to delta directory
if [ -r ${UPDATE_CFG_PATH} ]; then
	sudo cp ${UPDATE_CFG_PATH} ${DELTA_DIR}/update.cfg
	sudo rm ${UPDATE_CFG_PATH}
fi
if [ -r ${LOG_PATH} ]; then
	sudo cp ${LOG_PATH} ${RESULT_DIR}/Delta.log
	sudo rm ${LOG_PATH}
fi
if [ -r ${PRE_SCRIPT_PATH} ]; then
	sudo cp ${PRE_SCRIPT_PATH} ${DELTA_DIR}/pre.sh
fi

#--- extract files which would be appended to delta.tar ---
echo "Extract binaries for update from images"
fn_extract_from_image rootfs.img /usr/bin/upgrade-trigger.sh
fn_extract_from_image ramdisk-recovery.img /usr/bin/delta.ua

if [ -r ${UPDATE_CFG_PATH} ]; then
	sudo rm ${UPDATE_CFG_PATH}
fi
cd ${DELTA_DIR}
sudo cp ${COMMON_BINDIR}/unpack.sh ./
sudo tar --overwrite -czf ../delta.tar.gz *
cd -

rm -rf data

END_TIMESTAMP="$(date +%T)"

echo "OVERALL TIMESTAMP : [START] ${START_TIMESTAMP} ~ [END] ${END_TIMESTAMP}"

