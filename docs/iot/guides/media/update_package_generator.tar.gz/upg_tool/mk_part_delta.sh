#!/bin/bash


#==================
# funtions
#==================

#------------------------------------------------------------------------------
# Function :
#	fn_mk_attribute
#

fn_print_line()
{
	CHAR=$1
	NUM=$2

	echo "*******************************************************************"
}

#------------------------------------------------------------------------------
# Function :
#	fn_mk_attribute
#
# Params :
#	$1 - PART_NAME. to descriminate
#	$2 - base directory to search files for old partition
#	$3 - base directory to search files for new partition
#
# Description :
#	extract attribute information of files on the given partition
#

fn_mk_attribute()
{
	TARGET=$1
	BASE_DIR_OLD=$2
	BASE_DIR_NEW=$3
	V1_ATTR_FILE=${OUTPUT_DIR}/v1_${TARGET}_attr.txt
	V1_NAME_FILE=${OUTPUT_DIR}/v1_list.txt
	V2_ATTR_FILE=${OUTPUT_DIR}/v2_${TARGET}_attr.txt
	V2_NAME_FILE=${OUTPUT_DIR}/v2_list.txtfg
	V23_NAME_FILE=v23_${TARGET}_attr.txt
	V13_NAME_FILE=v13_${TARGET}_attr.txt
	ATTR_CMD=extended_attr.sh

	echo "Attribute generation for ${TARGET} [START] $(date +%T)"

	sudo find ./${BASE_DIR_OLD} -type f -printf '"/%P" Regular 14 %04m:%04U:%04G:' -exec ${COMMON_BINDIR}/${ATTR_CMD} {} \; >  ${V1_ATTR_FILE}
	sudo find ./${BASE_DIR_OLD} -type l -printf '"/%P" SymLink 14 %04m:%04U:%04G:' -exec ${COMMON_BINDIR}/${ATTR_CMD} {} \; >> ${V1_ATTR_FILE}
	sudo find ./${BASE_DIR_OLD} -type d -printf '"/%P" Regular 14 %04m:%04U:%04G:' -exec ${COMMON_BINDIR}/${ATTR_CMD} {} \; >> ${V1_ATTR_FILE}

	sudo find ./${BASE_DIR_NEW} -type f -printf '"/%P" Regular 14 %04m:%04U:%04G:' -exec ${COMMON_BINDIR}/${ATTR_CMD} {} \; >  ${V2_ATTR_FILE}
	sudo find ./${BASE_DIR_NEW} -type l -printf '"/%P" SymLink 14 %04m:%04U:%04G:' -exec ${COMMON_BINDIR}/${ATTR_CMD} {} \; >> ${V2_ATTR_FILE}
	sudo find ./${BASE_DIR_NEW} -type d -printf '"/%P" Regular 14 %04m:%04U:%04G:' -exec ${COMMON_BINDIR}/${ATTR_CMD} {} \; >> ${V2_ATTR_FILE}

	################ Change user and group permission from '0' to '0000' ############
	sed -i 's/:   0/:0000/g' ${V1_ATTR_FILE}
	sed -i 's/:   /:000/g' ${V1_ATTR_FILE}
	sed -i 's/:  /:00/g' ${V1_ATTR_FILE}
	sed -i 's/: /:0/g' ${V1_ATTR_FILE}

	sed -i 's/:   0/:0000/g' ${V2_ATTR_FILE}
	sed -i 's/:   /:000/g' ${V2_ATTR_FILE}
	sed -i 's/:  /:00/g' ${V2_ATTR_FILE}
	sed -i 's/: /:0/g' ${V2_ATTR_FILE}

	################ Change ":./old" to "/" ############
	sed -i "s/:.\/${BASE_DIR_OLD}\//:\//" ${V1_ATTR_FILE}
	sed -i "s/:.\/${BASE_DIR_OLD}/:\//" ${V1_ATTR_FILE}
	sed -i "s/:.\/${BASE_DIR_NEW}\//:\//" ${V2_ATTR_FILE}
	sed -i "s/:.\/${BASE_DIR_NEW}/:\//" ${V2_ATTR_FILE}

	echo "Attribut generation for ${TARGET} [END] $(date +%T)"
}

#------------------------------------------------------------------------------
# Function :
#	fn_mk_full_img
#

fn_mk_full_img()
{
	PART_IMG_ORG=${PART_BIN}
	PART_IMG_OLD=${PART_IMG_ORG}.old
	PART_IMG_NEW=${PART_IMG_ORG}.new

	#---- untar partition image and rename for old & new ----
	if [ ! "z${OLD_TAR_FILE}" = "z" ]; then
		echo "untar ${OLD_TAR_FILE}"
		tar xvf ${OLD_TAR_FILE} ${PART_IMG_ORG}
		if [ "$?" != "0" ]; then
			return 1;
		fi
		sudo mv ${PART_IMG_ORG} ${PART_IMG_OLD}
	fi

	echo "untar ${NEW_TAR_FILE}"
	tar xvf ${NEW_TAR_FILE} ${PART_IMG_ORG}
	if [ "$?" != "0" ]; then
		return 1;
	fi
	sudo mv ${PART_IMG_ORG} ${PART_IMG_NEW}

	if [ ! "z${OLD_TAR_FILE}" = "z" ]; then
		#---- check whether the binaries are same ----
		sudo diff ${PART_IMG_OLD} ${PART_IMG_NEW}
		if [ "$?" = "0" ]; then
			echo "[${PART_NAME}] two binaries are same"
			sudo rm -rf ${PART_IMG_OLD}
			sudo rm -rf ${PART_IMG_NEW}
			return 0
		fi
		sudo python ${COMMON_BINDIR}/CreatePatch.py ${UPDATE_TYPE} ${PART_NAME} ${PART_IMG_OLD} ${PART_IMG_NEW} ${OUTPUT_DIR} ${UPDATE_CFG_PATH}
		PythonRet=$?
		sudo rm ${PART_IMG_OLD}

		if [ $PythonRet != "0" ]; then
			echo "[${PART_NAME}] Failed to generate DELTA"
			exit 1
		fi
	fi

	sudo mv ${PART_IMG_NEW} ${OUTPUT_DIR}/${PART_IMG_ORG}
	sudo chown ${MY_ID}:${MY_ID} ${OUTPUT_DIR}/${PART_IMG_ORG}

	return 0
}

#------------------------------------------------------------------------------
# Function :
#	fn_mk_delta_img_core
#
# Description :
#	core routine for delta generation
#	Image Update Type
#

fn_mk_delta_img_core()
{

	START_TIMESTAMP="generation of ${DELTA} [START] $(date +%T)"

	#---- untar partition image and rename for old & new ----
	echo "untar ${OLD_TAR_FILE}"
	tar xvf ${OLD_TAR_FILE} ${PART_IMG_ORG}
	if [ "$?" != "0" ]; then
		return 1;
	fi
	sudo mv ${PART_IMG_ORG} ${PART_IMG_OLD}

	echo "untar ${NEW_TAR_FILE}"
	tar xvf ${NEW_TAR_FILE} ${PART_IMG_ORG}
	if [ "$?" != "0" ]; then
		return 1;
	fi
	sudo mv ${PART_IMG_ORG} ${PART_IMG_NEW}

	#---- check whether the binaries are same ----
	sudo diff ${PART_IMG_OLD} ${PART_IMG_NEW}
	if [ "$?" = "0" ]; then
		echo "[${PART_NAME}] two binaries are same"
		sudo rm -rf ${PART_IMG_OLD}
		sudo rm -rf ${PART_IMG_NEW}
		return 0
	fi

	#---- make delta file ----
	echo "make ${DELTA}"
	sudo python ${COMMON_BINDIR}/CreatePatch.py ${UPDATE_TYPE} ${PART_NAME} ${PART_IMG_OLD} ${PART_IMG_NEW} ${OUTPUT_DIR} ${UPDATE_CFG_PATH}
	PythonRet=$?
	#sudo xdelta delta ${PART_IMG_OLD} ${PART_IMG_NEW} ./${OUTPUT_DIR}/${PART_NAME}".delta"

	#---- remove files & directories ----
	echo "remove temp files/directory & move delta/log to result directory"
	sudo rm -rf ${PART_IMG_OLD}
	sudo rm -rf ${PART_IMG_NEW}
	sudo rm -rf x

	if [ $PythonRet != "0" ]; then
		echo "[${PART_NAME}] Failed to generate DELTA"
		exit 1
	fi
	END_TIMESTAMP="generation of ${DELTA} [END] $(date +%T)"
	echo "${START_TIMESTAMP}"
	echo "${END_TIMESTAMP}"


	return 0
}

#------------------------------------------------------------------------------
# Function :
#	fn_mk_delta_img
#
# Description :
#	generate delta file for image type partition
#

fn_mk_delta_img()
{
	PART_IMG_ORG=${PART_BIN}
	PART_IMG_OLD=${PART_IMG_ORG}.old
	PART_IMG_NEW=${PART_IMG_ORG}.new

	DELTA=${DELTA_BIN}
	DEBUG_DELTA=debug_${DELTA}
	#CFG_XML=${PART_NAME}_IMG.xml
	mkdir ${OUTPUT_DIR}/i
	fn_mk_delta_img_core
	if [ "$?" != "0" ]; then
		return 1
	fi

	return 0

}
#------------------------------------------------------------------------------
# Function :
#	mk_inter_attrib_file
#
# Description :
#	makes a list of attributes for those files which differ between v1 aND V2
#manoj:to create intermediate attribute list
fn_mk_inter_attrib_file()
{
	V1ref_ATTR_FILE=${OUTPUT_DIR}/v1_${TARGET}_attr.txt
	V2ref_ATTR_FILE=${OUTPUT_DIR}/v2_${TARGET}_attr.txt
}

#------------------------------------------------------------------------------
# Function :
#	fn_mk_delta_fs_core
#
# Description :
#	core routine for delta generation
#	File System Update Type (DELTA_FS)
#

fn_mk_delta_fs_core()
{
	START_TIMESTAMP="generation of ${DELTA} [START] $(date +%T)"
	FS=ext4

	if [ "${DELTA}" = "boot.img/" ]; then
		FS=vfat
	fi

	#---- untar partition image and rename for old & new ----
	echo "untar ${OLD_TAR_FILE}"
	tar xvf ${OLD_TAR_FILE} ${PART_IMG_ORG}
	if [ "$?" != "0" ]; then
		return 1;
	fi
	sudo mv ${PART_IMG_ORG} ${PART_IMG_OLD}

	echo "untar ${NEW_TAR_FILE}"
	tar xvf ${NEW_TAR_FILE} ${PART_IMG_ORG}
	if [ "$?" != "0" ]; then
		return 1;
	fi
	sudo mv ${PART_IMG_ORG} ${PART_IMG_NEW}

	#---- check whether the binaries are same ----
	sudo diff ${PART_IMG_OLD} ${PART_IMG_NEW}
	if [ "$?" = "0" ]; then
		echo "[${PART_NAME}] two binaries are same"
		sudo rm -rf ${PART_IMG_OLD}
		sudo rm -rf ${PART_IMG_NEW}
		sudo rm -rf ${OUTPUT_DIR}
		return 0
	fi

	#---- make mount point ----
	mkdir -p ${MNT_PNT_OLD}
	mkdir -p ${MNT_PNT_NEW}

	#---- mount partition image to mount point  ----
	echo "mount ${PART_IMG_OLD} & ${PART_IMG_NEW}"
	sudo mount -t ${FS} -o loop ${PART_IMG_OLD} ${MNT_PNT_OLD}
	if [ "$?" != "0" ]; then
		return 1;
	fi
	sudo mount -t ${FS} -o loop ${PART_IMG_NEW} ${MNT_PNT_NEW}
	if [ "$?" != "0" ]; then
		return 1;
	fi

	#---- remove unnecessary files & directories  ----
	for ff in ${EXCLUDE_FILES}
	do
		sudo rm -rf ${MNT_PNT_OLD}/${ff}
		sudo rm -rf ${MNT_PNT_NEW}/${ff}
	done

	#---- make attribute ----
	fn_mk_attribute ${PART_NAME} ${BASE_OLD} ${BASE_NEW}

	#PART_IMG_ORG parameter should match with DELTA name that is part of default config file. Which will be used to update MAX size file that is present in respective partition.
	sudo python ${COMMON_BINDIR}/CreatePatch.py ${UPDATE_TYPE} ${PART_NAME} ${BASE_OLD} ${BASE_NEW} ${OUTPUT_DIR} ${V1_ATTR_FILE} ${V2_ATTR_FILE} ${UPDATE_CFG_PATH}
	PythonRet=$?

	#---- unmount partition image ----
	echo "umount ${MNT_PNT_OLD} & ${MNT_PNT_NEW}"
	sudo umount ${MNT_PNT_OLD}
	sudo umount ${MNT_PNT_NEW}

	#---- remove files & directories ----
	echo "remove temp files/directory & move delta/log to result directory"
	sudo rm -rf ${PART_IMG_OLD}
	sudo rm -rf ${PART_IMG_NEW}
	sudo rm -rf ${BASE_OLD} ${BASE_NEW}
	sudo rm -rf x

	if [ $PythonRet != "0" ]; then
		echo "[${PART_NAME}] Failed to generate DELTA"
		exit 1
	fi
	END_TIMESTAMP="generation of ${DELTA} [END] $(date +%T)"
	echo "${START_TIMESTAMP}"
	echo "${END_TIMESTAMP}"

	return 0
}

#------------------------------------------------------------------------------
# Function :
#	Mk_delta_fs
#
# Description :
#	generate delta file for filesystem type partition
#

fn_mk_delta_fs()
{
	PART_IMG_ORG=${PART_BIN}
	PART_IMG_OLD=${PART_IMG_ORG}.old
	PART_IMG_NEW=${PART_IMG_ORG}.new

	DELTA=${DELTA_BIN}
	DEBUG_DELTA=debug_${DELTA}
	#CFG_XML=${PART_NAME}_FS.xml

	FAKE_ROOT=system
	BASE_OLD=${PART_NAME}_OLD
	BASE_NEW=${PART_NAME}_NEW

	#--- !!! this should be modified according to partition ---
	case "${PART_NAME}" in
	"rootfs" )
		EXCLUDE_FILES="lost+found dev proc tmp var sys csa"
		TGT_MNT_PNT=${FAKE_ROOT}
		;;
	"ramdisk1" | "ramdisk" )
		EXCLUDE_FILES="lost+found dev proc tmp sys"
		TGT_MNT_PNT=${FAKE_ROOT}/mnt/initrd
		;;
	"ramdisk2" | "ramdisk-recovery" )
		EXCLUDE_FILES="lost+found"
		TGT_MNT_PNT=${FAKE_ROOT}/mnt/initrd-recovery
		;;
	"user" )
		EXCLUDE_FILES="lost+found"
		TGT_MNT_PNT=${FAKE_ROOT}/opt/usr
		;;
	"system-data" )
		EXCLUDE_FILES="lost+found"
		TGT_MNT_PNT=${FAKE_ROOT}/opt
		;;
	"kernel" | "boot" )
		EXCLUDE_FILES=""
		TGT_MNT_PNT=${FAKE_ROOT}/boot
		;;
	* )
		echo "${PART_NAME} not supported !!!"
		return 1
		;;
	esac

	MNT_PNT_OLD=${BASE_OLD}/${TGT_MNT_PNT}
	MNT_PNT_NEW=${BASE_NEW}/${TGT_MNT_PNT}


	fn_mk_delta_fs_core
	if [ "$?" != "0" ]; then
		return 1
	fi

	return 0
}

#------------------------------------------------------------------------------
# Function :
#	fn_mk_flash_img
#

fn_mk_flash_img()
{
	PART_IMG_NEW=${PART_BIN}

	#---- untar partition image and rename for old & new ----
	echo "untar ${NEW_TAR_FILE}"
	tar xvf ${NEW_TAR_FILE} ${PART_IMG_NEW}
	if [ "$?" != "0" ]; then
		return 1;
	fi

	sudo mv ${PART_IMG_NEW} ${OUTPUT_DIR}/${PART_BIN}
	sudo chown ${MY_ID}:${MY_ID} ${OUTPUT_DIR}/${PART_BIN}

	return 0
}



#------------------------------------------------------------------------------
# Function :
#	get_tar_file_names
#
# Description :
#	find tar file name (without path) that contains given partition binary
#

fn_get_tar_file_names()
{
	BIN_TO_FIND=$1

	echo "Test tar: ${OLD_TAR_FILE}, ${NEW_TAR_FILE}"

	#--- test each tar contains the binary ---
	result=`tar -tvf ${OLD_TAR_FILE} | grep " ${BIN_TO_FIND}$"`
	if [ ! "$?" = "0" ]; then
		OLD_TAR_FILE=
	fi

	result=`tar -tvf ${NEW_TAR_FILE} | grep " ${BIN_TO_FIND}$"`
	if [ ! "$?" = "0" ]; then
		NEW_TAR_FILE=
	fi
}

###############################################################################
#==================
# Main Start
#==================

fn_print_line - 80

#--- assign input params to internal variables ---
param_num=$#
if [ "${param_num}" != "4" ]; then
	echo "Invalid param num"
	echo "[Usage] $0 PART_NAME UPDATE_TYPE PART_BIN DELTA_BIN"
	exit 1
fi

PART_NAME=$1
UPDATE_TYPE=$2
PART_BIN=$3
DELTA_BIN=$4

#--- set some default variables ---
MY_ID=`whoami`
CUR_DIR=`pwd`
DATA_DIR=./data
COMMON_BINDIR=${CUR_DIR}
UPDATE_CFG_PATH=./update.cfg

#--- check if the current working directory is the parent directory of bin, data, cfg, xml ---
TEST_DIR=${DATA_DIR}
if [ ! -d ${TEST_DIR} ]; then
	echo "Invalid working directory. ${TEST_DIR} does not exist"
	exit 1
fi

#fn_get_tar_file_names ${PART_BIN}

if [ "z${OLD_TAR_FILE}" = "z" ]; then
	if [ ! "${UPDATE_TYPE}" = "FULL_IMG" ] && [ ! "${UPDATE_TYPE}" = "PRE_UA" ]; then
		echo "[old] tar file ${OLD_TAR_FILE} does not contains ${PART_BIN}"
		#exit 0, cos this is not an error.
		exit 0
	fi
fi

if [ "z${NEW_TAR_FILE}" = "z" ]; then
	echo "[new] tar file ${OLD_TAR_FILE} does not contains ${PART_BIN}"
	exit 0
fi

if [ ! "z${OLD_TAR_FILE}" = "z" ]; then
	echo "[old] ${OLD_TAR_FILE} contains ${PART_BIN}"
fi
echo "[new] ${NEW_TAR_FILE} contains ${PART_BIN}"


#--- generate delta binary ---

cd ${DATA_DIR}

OUTPUT_DIR=${PART_NAME}_OUT
if [ ! -d ${OUTPUT_DIR} ]; then
	if [ -f ${OUTPUT_DIR} ]; then
		sudo rm -f ${OUTPUT_DIR}
	fi
	mkdir ${OUTPUT_DIR}
fi

if [ "${UPDATE_TYPE}" = "FULL_IMG" ] || [ "${UPDATE_TYPE}" = "PRE_UA" ]; then
	fn_mk_full_img
#elif [ "${UPDATE_TYPE}" = "DELTA_IMG" ]; then
#	fn_mk_delta_img
#elif [ "${UPDATE_TYPE}" = "DELTA_FS" ]; then
#	fn_mk_delta_fs
else
	echo "Invalid update type"
	exit 1
fi

exit 0
