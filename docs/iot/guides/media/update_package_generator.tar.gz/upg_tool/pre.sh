#!/bin/bash

# Mount boot image for updating ramdisk(-recovery)
mkdir -p /tmp/boot
mount LABEL=boot /tmp/boot
